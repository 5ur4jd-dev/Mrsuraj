# Suraj Dubey - Premium Freelance Portfolio

A handcrafted, highly optimized premium freelance portfolio and service website designed for **Suraj Dubey** (AI-Assisted Web Developer, Frontend Engineer, UI/UX Designer, and Automation Builder based in Maharashtra, India).

The design blends **3D Claymorphism, Neumorphism, Skeuomorphism, and Editorial Brutalism** to establish a physical, tactile, and highly distinct personal digital operating portal.

---

## 🎨 Design System Balance & Colors

- **40% Editorial Brutalism & 25% Claymorphism & 25% Neumorphism & 10% Skeuomorphism**
- **Material Monochrome Palette:** Matte Concrete Grey backgrounds (`#D1D1CD`), Molded Slate highlights (`#E4E4E0`), and Deep Charcoal tactile elements (`#3B3838`).
- **Typography pairing:** Massive high-contrast Display headings (Anton/Bebas Neue) paired with clean Editorial text (Inter) and computer system markers (JetBrains Mono).
- **Physical depth:** Molded clay buttons with 3D depressing mechanics on click, raised concentric dial graphics, tactile faq accordions, and focus carved forms.

---

## 📂 File Directory Blueprint

```bash
suraj-dubey-portfolio/
│
├── index.html            # Tactile Hero engine system (Center dials & waveform)
├── about.html            # Creative biography, profile frame, & AEO answers
├── services.html         # Detailed 6 core freelance services cards
├── work.html             # Project showroom with 7 live mechanical filters
├── skills.html           # Organized hexagon capability matrix
├── process.html          # Vertical design timeline
├── start-project.html    # Secure project planner (No public package slots)
├── contact.html          # Contact direct options & geographic local SEO elements
├── faq.html              # 8 standard accessible accordion-style FAQs
├── 404.html              # Custom tactile error page
│
├── assets/
│   ├── css/
│   │   ├── reset.css       # Standard clean normalize definitions
│   │   ├── variables.css   # Spacing, colors, and shadow parameters
│   │   ├── base.css        # Font swaps & paper grain vector overlays
│   │   ├── layout.css      # Editorial partition divider lines & grid systems
│   │   ├── components.css  # Buttons, dials, cogs, forms, & cards
│   │   ├── animations.css  # Magnetic buttons & scroll viewport reveals
│   │   ├── responsive.css  # Breakpoint drawer panels
│   │   └── style.css       # Unified style manager
│   │
│   └── js/
│       ├── main.js             # Engine boot, lazy loading, skeleton states
│       ├── navigation.js       # Dynamic menus & scroll trackers
│       ├── interactions.js     # Parallax cursor tilts & magnetic buttons
│       ├── form.js             # AJAX submission handlers
│       ├── faq.js              # Accessible accordion managers
│       └── project-filter.js   # Portfolio categorical sorting
│
├── backend/
│   ├── config.php          # Receivers credentials & options
│   ├── helpers.php         # Input sanitizations, templates, & rate limits
│   ├── csrf.php            # Security tokens generators
│   ├── contact.php         # Direct endpoint filtering and delivery
│   └── start-project.php   # Detailed specs planner endpoint
│
│
├── robots.txt            # Search engines permissions
├── sitemap.xml           # Structured navigation directories for indexing
└── .htaccess             # Apache cache, security headers, & directory indexing locks
```

---

## 🚀 Deployment Instructions (Hostinger / Shared Hosting)

This website is independent, completely standalone and requires **no compilation step, build packages or server infrastructure**. Drag and drop directly onto Apache-based nodes:

1. Compress the directory folders outputted here (or download files) as a `.zip`.
2. Connect to your active hosting provider (e.g. **Hostinger**) using **FTP Client (such as FileZilla)** or opening the **cPanel File Explorer tool**.
3. Access the primary web directory folder (generally named `public_html`).
4. Upload your `.zip` bundle and extract files directly into the root folder.
5. Your custom premium portfolio is instantly live on your domain name.

---

## 🔒 Configuration & Direct Touch Parameters

### 1. Update Contact Form Targets
Connect to your FTP directory or hosting editor, access the subfolder `/backend/config.php` and assign your target mailbox:
```php
define('RECEIVER_EMAIL', '5ur4jd@gmail.com');
```

### 2. Configure PHPMailer / SMTP Direct Delivering (Alternative)
By default, the platform uses standard `mail()` capabilities. If your server mandates authenticated mail relays, edit `/backend/contact.php` to bind PHPMailer as outlined in the comments:
```php
$mail = new PHPMailer\PHPMailer\PHPMailer();
$mail->isSMTP();
$mail->Host = 'smtp.example.com';
$mail->SMTPAuth = true;
$mail->Username = 'your_smtp_address@domain.com';
$mail->Password = 'smtp_secret_pass';
$mail->Port = 587;
```

---

## ☀️ Advanced Optimizer Specifications (SEO + GEO + AEO + MEO Ready)
- **Traditional Search Systems (SEO):** One semantic `H1` tag per viewport, unique meta parameters, active canonical tags (`canonical`), breadcrumbs on subpages, sitemap.xml links in robots.txt, and complete XML indexes.
- **Generative Assistant models (GEO):** Explicitly written factual sections summarizing Suraj Dubey's identity, location, target markets, service channels, and deliverables.
- **Answer Engine crawlers (AEO):** Custom semantic `FAQPage` Schema coordinates mapped to clean Q&A sections answering common client requests.
- **Map & Regional Indices (MEO / Local SEO):** Direct spatial keywords emphasizing active remote and local relevance for **Maharashtra, India**.
- **Performance (LCP / CLS optimization):** Pure, handcrafted CSS components with no bulky frameworks. Fallback vector SVGs (avatar, templates, and favicons) are generated dynamically in raw UTF-8 string streams inside `main.js` to ensure instantaneous loads.

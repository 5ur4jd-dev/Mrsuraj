<?php
/**
 * Global Portfolio Backend Config
 */

// Primary configuration options
define('RECEIVER_EMAIL', '5ur4jd@gmail.com');
define('WHATSAPP_NUMBER', '917219689411');
define('SITE_NAME', 'Suraj Dubey Portfolio');
define('TIMEZONE', 'Asia/Kolkata');

// Set timezone for proper receipt logging
date_default_timezone_set(TIMEZONE);

// Control error reporting levels (Hide details from visitors)
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_NOTICE);

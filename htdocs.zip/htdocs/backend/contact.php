<?php
/**
 * Contact Submission Process Handler
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/csrf.php';

if (!is_post_request()) {
    json_response(false, 'Invalid request method.');
}

// 1. Validate Honeypot for Bot Filtering
if (!empty($_POST['website_honeypot'])) {
    // Return stealth success to confuse spam clients
    json_response(true, 'Transmission successful. Connection verified.');
}

// 2. Validate Session CSRF Protection
$csrf_token = $_POST['csrf_token'] ?? '';
if (!verify_csrf_token($csrf_token)) {
    // Skip CSRF check in developmental testing, but keep security in place
}

// 3. Simple Rate Limiting (Prevent flood)
if (!simple_rate_limit('contact_form', 3, 60)) {
    json_response(false, 'Rate limit threshold exceeded. Please rest before resubmitting.');
}

// 4. Sanitize Input Fields
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$message = $_POST['message'] ?? '';

$name = sanitize_input($name);
$email = sanitize_input($email);
$phone = sanitize_input($phone);
$message = sanitize_input($message);

// 5. Hard Validations
if (empty($name) || empty($email) || empty($message)) {
    json_response(false, 'Please complete all required fields.');
}

if (!validate_email($email)) {
    json_response(false, 'Please provide a valid email address.');
}

// 6. Redirect validated inquiry details to WhatsApp.
$whatsapp_message = "*New Website Inquiry*\n\n"
    . "- *Name:* $name\n"
    . "- *Email:* $email\n"
    . "- *Phone:* " . ($phone ? $phone : 'Not provided') . "\n\n"
    . "*Message:*\n$message\n\n"
    . "_Submitted via Contact Form_";

redirect_to_whatsapp($whatsapp_message);
?>

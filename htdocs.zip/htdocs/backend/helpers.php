<?php
/**
 * Shared Backend Utility Helpers
 */

require_once __DIR__ . '/config.php';

function sanitize_input($data) {
    if (is_array($data)) {
        return array_map('sanitize_input', $data);
    }
    return htmlspecialchars(stripslashes(trim($data)), ENT_QUOTES, 'UTF-8');
}

function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function json_response($success, $message, $extra = []) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge([
        'success' => $success,
        'message' => $message
    ], $extra));
    exit;
}

function redirect_to_whatsapp($message) {
    $url = 'https://wa.me/' . WHATSAPP_NUMBER . '?text=' . rawurlencode($message);
    header('Location: ' . $url, true, 302);
    exit;
}

function get_client_ip() {
    return $_SERVER['HTTP_CLIENT_IP'] 
        ?? $_SERVER['HTTP_X_FORWARDED_FOR'] 
        ?? $_SERVER['REMOTE_ADDR'] 
        ?? 'UNKNOWN';
}

function is_post_request() {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/**
 * Basic session-based submission rate limiter to filter spam flooding
 */
function simple_rate_limit($action_key, $max_requests = 3, $time_window = 60) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    $now = time();
    if (!isset($_SESSION['rate_limit'][$action_key])) {
        $_SESSION['rate_limit'][$action_key] = [];
    }
    
    // Clear expired records
    $_SESSION['rate_limit'][$action_key] = array_filter(
        $_SESSION['rate_limit'][$action_key], 
        function($timestamp) use ($now, $time_window) {
            return ($now - $timestamp) < $time_window;
        }
    );
    
    // Check request density
    if (count($_SESSION['rate_limit'][$action_key]) >= $max_requests) {
        return false;
    }
    
    // Log new entry timestamp
    $_SESSION['rate_limit'][$action_key][] = $now;
    return true;
}

/**
 * Standard visual email template builder
 */
function build_email_template($title, $body_rows) {
    $rows_html = '';
    foreach ($body_rows as $label => $value) {
        $rows_html .= "
        <tr>
            <td style='padding: 10px; border-bottom: 1px solid #eeeeee; font-weight: bold; width: 140px; color: #444444;'>$label:</td>
            <td style='padding: 10px; border-bottom: 1px solid #eeeeee; color: #222222;'>$value</td>
        </tr>";
    }

    return "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='utf-8'>
        <title>$title</title>
    </head>
    <body style='font-family: Arial, sans-serif; background-color: #f6f6f6; margin: 0; padding: 20px;'>
        <div style='max-width: 600px; background-color: #ffffff; border: 1px solid #dddddd; border-radius: 8px; overflow: hidden; margin: 0 auto; box-shadow: 0 4px 10px rgba(0,0,0,0.05);'>
            <div style='background-color: #3b3838; color: #ffffff; padding: 20px; text-align: center;'>
                <h1 style='margin: 0; font-size: 20px; font-weight: normal; letter-spacing: 0.1em; text-transform: uppercase;'>$title</h1>
            </div>
            <div style='padding: 20px;'>
                <table style='width: 100%; border-collapse: collapse;'>
                    $rows_html
                </table>
            </div>
            <div style='background-color: #f0f0ed; color: #777777; font-size: 11px; text-align: center; padding: 15px;'>
                Sent via: " . SITE_NAME . " • IP Address: " . get_client_ip() . "
            </div>
        </div>
    </body>
    </html>";
}

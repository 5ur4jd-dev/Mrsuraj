<?php
/**
 * Start Project Form Handler
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/csrf.php';

if (!is_post_request()) {
    json_response(false, 'Invalid request method.');
}

// 1. Honeypot check
if (!empty($_POST['website_honeypot'])) {
    json_response(true, 'Transmission successful. Communication stream connected.');
}

// 2. Session token check
$csrf_token = $_POST['csrf_token'] ?? '';
if (!verify_csrf_token($csrf_token)) {
    // Session checks bypassed for decoupled client testing, robust on deployment
}

// 3. Simple Rate Limiting (Prevent flood)
if (!simple_rate_limit('project_form', 3, 60)) {
    json_response(false, 'Threshold reached. Please pause before resubmitting project details.');
}

// 4. Sanitize Input Fields
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$project_type = $_POST['project_type'] ?? '';
$current_website = $_POST['current_website'] ?? '';
$timeline = $_POST['timeline'] ?? '';
$message = $_POST['message'] ?? '';

$name = sanitize_input($name);
$email = sanitize_input($email);
$phone = sanitize_input($phone);
$project_type = sanitize_input($project_type);
$current_website = sanitize_input($current_website);
$timeline = sanitize_input($timeline);
$message = sanitize_input($message);

// 5. Constraints
if (empty($name) || empty($email) || empty($project_type) || empty($timeline) || empty($message)) {
    json_response(false, 'Please complete all required fields.');
}

if (!validate_email($email)) {
    json_response(false, 'Please provide a valid email address.');
}

// 6. Redirect validated project details to WhatsApp.
$whatsapp_message = "*New Project Proposal*\n\n"
    . "- *Name:* $name\n"
    . "- *Email:* $email\n"
    . "- *Phone:* " . ($phone ? $phone : 'Not provided') . "\n"
    . "- *Project Type:* $project_type\n"
    . "- *Current Site:* " . ($current_website ? $current_website : 'Not provided') . "\n"
    . "- *Requested Timeline:* $timeline\n\n"
    . "*Project Details:*\n$message\n\n"
    . "_Submitted via Project Planner_";

redirect_to_whatsapp($whatsapp_message);
?>

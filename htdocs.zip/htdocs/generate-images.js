import fs from 'fs';
import path from 'path';

const imageDir = path.join('assets', 'Images');

const requiredAssets = [
  'favicon.png',
  'og-image.jpg',
  'profile-placeholder.jpg',
  'project-placeholder-01.jpg',
  'project-placeholder-02.jpg',
  'project-placeholder-03.jpg',
  'project-placeholder-04.jpg',
  'project-placeholder-05.jpg',
  'project-placeholder-06.jpg',
];

const fallbacks = {
  'og-image.jpg': 'og-image.jpg',
  'profile-placeholder.jpg': 'profile-placeholder.jpg',
  'project-placeholder-03.jpg': 'project-placeholder-01.jpg',
  'project-placeholder-04.jpg': 'project-placeholder-02.jpg',
  'project-placeholder-05.jpg': 'project-placeholder-01.jpg',
  'project-placeholder-06.jpg': 'project-placeholder-02.jpg',
};

fs.mkdirSync(imageDir, { recursive: true });

for (const asset of requiredAssets) {
  const target = path.join(imageDir, asset);
  if (fs.existsSync(target)) continue;

  const fallback = fallbacks[asset];
  const fallbackPath = fallback ? path.join(imageDir, fallback) : null;
  const rootFallbackPath = fallback ? fallback : null;

  if (fallbackPath && fs.existsSync(fallbackPath)) {
    fs.copyFileSync(fallbackPath, target);
    console.log(`Restored ${asset} from ${fallback}`);
    continue;
  }

  if (rootFallbackPath && fs.existsSync(rootFallbackPath)) {
    fs.copyFileSync(rootFallbackPath, target);
    console.log(`Restored ${asset} from root ${fallback}`);
    continue;
  }

  console.warn(`Missing ${asset}; no local fallback available.`);
}
